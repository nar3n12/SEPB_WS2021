package Task3;

public class List {

    Node head;


    public static double calculateTotal(List list){

        double total = 0;

        if(list.head != null){
            Node last = list.head;
            while (last.next != null){
                total += (last.record.prize * last.record.amount);
                last = last.next;
            }
        }


        return total;
    }

    public static List splitByType(List list,ProductType type){

        List newlist = new List();
        if(list.head != null){
            Node last = list.head;
            Node prev = null;

            while (last.next != null) {
                if(last.record.productType == type){
                    insert(newlist,last.record);
                    if(prev!=null)
                    prev.next = last.next;
                }
                prev = last;
                last = last.next;

            }


        }


        return newlist;
    }

    public static List merge(List alist,
                              List blist) {
        if (alist.head == null) {
            return blist;
        }
        else if(blist.head == null){
            return alist;
        }
        else{
            Node lastB = blist.head;

            while (lastB.next != null) {
                insert(alist,lastB.record);
                lastB = lastB.next;
            }


        }

        return alist;
    }

    public static List insert(List list,
                                    Record record)
    {
        // Create a new node with given record
        Node new_node = new Node(record);
        boolean skipFlag = false;

        // If the Linked List is empty,
        // then make the new node as head
        if (list.head == null) {
            list.head = new_node;
        }
        else {
            // Else traverse till the last node
            // and insert the new_node there
            Node last = list.head;
            while (last.next != null) {
                if(last.record.name != new_node.record.name)
                    last = last.next;
                else{
                    last.record.amount += new_node.record.amount;
                    skipFlag = true;
                    break;
                }
            }

            // Insert the new_node at last node
            if(!skipFlag)
            last.next = new_node;
        }

        // Return the list by head
        return list;
    }

}
