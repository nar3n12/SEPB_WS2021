package Task3;

public enum ProductType {
    FOOD,
    NONFOOD,
    BEVERAGES
}
