package Task3;

public class Record {
    String name;
    double prize;
    int amount;
    ProductType productType;

    public Record(String name, double prize, int amount, ProductType productType) {
        this.name = name;
        this.prize = prize;
        this.amount = amount;
        this.productType = productType;
    }


}
